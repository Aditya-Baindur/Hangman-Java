package com.mycompany.summative_aditya;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JButton;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

import javax.swing.ImageIcon;

/**
 * @date : 23 June 2023; 22:10 PM MST
 * 
 * @author adityabaindur
 * 
 * @class ICS 4U - 03; Mr Bates
 * 
 * @purpose :  This program creates the game hangman 
 * 
 * @references : Lesson attached files and artist, Vidya Baindur
 * Data Sets : https://github.com/fecrol/JHangman/tree/main/words
 *
 * @Additional features : 

- Word List: The program uses a collection of diverse word lists, providing a wide range of words for guessing.

- Hangman Image: As you make incorrect guesses, a visual representation of the hangman will appear, adding excitement to the gameplay.

- Keyboard Buttons: The program provides an on-screen keyboard for ease of input, allowing you to click on letters instead of typing.

- Game Status Display: The program displays the number of remaining tries and the current state of the word, making it easy to track your progress.

- Customization: Allows you to add and remove word/s to an existing category

- There is a timer at the top right which keeps track of the time you take to reply, but does not change your score. 

- Scoreboard, which will add 10 marks per correct letter guessed and remove 10 per game lost.
* 

 * - Sets the file location automatically as it is already in the project file
 * 
 * - Please review the attached User Guide: Hangman Game Software for more information about the game. 
 * 
 * - All the panes are set to be located in the middle of the users screens               
 */

public class Game_frame extends javax.swing.JFrame {

    private static String[] WORDS; // Array to store the words for the game
    private static final int MAX_TRIES = 7; // Maximum number of tries for the player
    private String selectedWord; // The word selected for the current game
    private char[] wordState; // The current state of the word with guessed letters
    private int triesLeft; // Number of tries remaining for the player
    private int timerSeconds; // Number of seconds elapsed in the game timer
    private javax.swing.Timer timer; // Timer for the game
    private int score; // Current score of the player

    public Game_frame() {
        initComponents();
        initializeGame(); // Initialize the game state
        attachButtonListeners(); // Attach listeners to keyboard buttons
    }

    // Initialize the game state
    private void initializeGame() {
        score = 0; // Reset the score
        updateScore(0); // Update the score label
        startTimer(); // Start the game timer

        // Set the JFrame location to the middle of the screen
        setLocationRelativeTo(null);
        
        try {
            ArrayList<String> wordList = new ArrayList<>();

            BufferedReader reader = new BufferedReader(new FileReader(Main_form.Category));

            String line;
            while ((line = reader.readLine()) != null) {
                wordList.add(line);
            }

            WORDS = wordList.toArray(new String[0]);

            reader.close();
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }

        Random random = new Random();
        String previousWord = selectedWord; // Store the previous selected word
        do {
            selectedWord = WORDS[random.nextInt(WORDS.length)];
        } while (selectedWord.equals(previousWord)); // Generate a new word until it's different

        // Update wordState to consider spaces
        wordState = new char[selectedWord.length()];
        for (int i = 0; i < selectedWord.length(); i++) {
            char c = selectedWord.charAt(i);
            if (c == ' ') {
                wordState[i] = ' ';
            } else {
                wordState[i] = '_';
            }
        }

        triesLeft = MAX_TRIES;
        updateDisplay(); // Update the word display
        updateHangmanImage("Page1.png"); // Set the starting image for hangman
    }

    // Start the game timer
    private void startTimer() {
        timerSeconds = 0;
        timer = new javax.swing.Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                timerSeconds++;
                int minutes = timerSeconds / 60;
                int seconds = timerSeconds % 60;
                String time = String.format("%02d:%02d", minutes, seconds);
                Timer_lable.setText("Timer: " + time);
            }
        });
        timer.start();
    }

    // Stop the game timer
    private void stopTimer() {
        if (timer != null) {
            timer.stop();
        }
    }

    // Update the score with the given increment
    private void updateScore(int increment) {
        score += increment;
        if (score < 0) {
            score = 0; // Ensure the score doesn't go below zero
        }
        Score_lable.setText("Score: " + score);
    }

    // Attach listeners to keyboard buttons
    private void attachButtonListeners() {
        ActionListener buttonListener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JButton button = (JButton) e.getSource();
                button.setEnabled(false);
                char guess = button.getText().charAt(0);
                boolean found = checkLetter(guess); // Check if the guessed letter is correct

                updateDisplay(); // Update the word display
                checkGameOver(); // Check if the game is over
            }
        };

        // Attach the listener to all keyboard buttons
        JButton[] buttons = {
            Q_btn, W_btn, E_btn, R_btn, T_btn, Y_btn, U_btn, I_btn, O_btn, P_btn,
            A_btn, S_btn, D_btn, F_btn, G_btn, H_btn, J_btn, K_btn, L_btn,
            Z_btn, X_btn, C_btn, V_btn, B_btn, N_btn, M_btn
        };
        for (JButton button : buttons) {
            button.addActionListener(buttonListener);
        }
    }

    // Update the word display
    private void updateDisplay() {
        StringBuilder wordBuilder = new StringBuilder();
        for (char c : wordState) {
            if (c == ' ') {
                wordBuilder.append(" ");
            } else if (c != '\u0000') {
                wordBuilder.append(c);
            } else {
                wordBuilder.append("_");
            }
            wordBuilder.append(" ");
        }
        jTextField1.setText(wordBuilder.toString().trim());
    }

    // Update the hangman image with the given imageName
    private void updateHangmanImage(String imageName) {
        try {
            File imageFile = new File(imageName);

            if (imageFile.exists() && imageFile.isFile()) {
                BufferedImage image = ImageIO.read(imageFile);

                int width = image.getWidth();
                int height = image.getHeight();

                if (width != 0 && height != 0) {
                    Image scaledImage = image.getScaledInstance(Hangman_label.getWidth(), Hangman_label.getHeight(), Image.SCALE_AREA_AVERAGING);
                    Hangman_label.setIcon(new ImageIcon(scaledImage));
                } else {
                    System.err.println("Error loading image: Invalid image dimensions.");
                }
            } else {
                System.err.println("Error loading image: Image file not found.");
            }
        } catch (IOException e) {
            System.err.println("Error loading image: " + e.getMessage());
        }
    }

    // Decrement the number of tries remaining
    private void decrementTries() {
        triesLeft--;
        updateHangmanImage("Page" + (MAX_TRIES - triesLeft + 1) + ".png"); // Update the hangman image
    }

    // Check if the guessed letter is correct
    private boolean checkLetter(char guess) {
        boolean found = false;
        char lowercaseGuess = Character.toLowerCase(guess);
        for (int i = 0; i < selectedWord.length(); i++) {
            if (Character.toLowerCase(selectedWord.charAt(i)) == lowercaseGuess) {
                wordState[i] = selectedWord.charAt(i);
                found = true;
            }
        }

        if (!found) {
            decrementTries(); // Incorrect guess, decrement the number of tries remaining
        } else {
            updateScore(10); // Increment the score by 10 when a correct letter is guessed
        }
        return found;
    }

    // Check if the game is over
    private void checkGameOver() {
        if (triesLeft == 0) {
            // Game lost
            jTextField1.setText("Game Over! You lost. The word was: " + selectedWord);
            Keyboard_enable(false); // Disable keyboard buttons
            stopTimer(); // Stop the game timer
            updateScore(-100); // Deduct 100 points for losing
        } else if (!new String(wordState).contains("_")) {
            // Game won
            jTextField1.setText("Congratulations! You won!");
            Keyboard_enable(false); // Disable keyboard buttons
            stopTimer(); // Stop the game timer
            updateScore(80); // Add 80 points for winning
        }
    }

    // Enable or disable keyboard buttons
    private void Keyboard_enable(boolean ans) {
        // Disable all keyboard buttons
        JButton[] buttons = {
            Q_btn, W_btn, E_btn, R_btn, T_btn, Y_btn, U_btn, I_btn, O_btn, P_btn,
            A_btn, S_btn, D_btn, F_btn, G_btn, H_btn, J_btn, K_btn, L_btn,
            Z_btn, X_btn, C_btn, V_btn, B_btn, N_btn, M_btn
        };
        for (JButton button : buttons) {
            button.setEnabled(ans);
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Main_panel = new javax.swing.JPanel();
        QWERTY_keyboard = new javax.swing.JPanel();
        Q_btn = new javax.swing.JButton();
        W_btn = new javax.swing.JButton();
        R_btn = new javax.swing.JButton();
        E_btn = new javax.swing.JButton();
        T_btn = new javax.swing.JButton();
        Y_btn = new javax.swing.JButton();
        U_btn = new javax.swing.JButton();
        I_btn = new javax.swing.JButton();
        O_btn = new javax.swing.JButton();
        P_btn = new javax.swing.JButton();
        A_btn = new javax.swing.JButton();
        S_btn = new javax.swing.JButton();
        D_btn = new javax.swing.JButton();
        F_btn = new javax.swing.JButton();
        G_btn = new javax.swing.JButton();
        H_btn = new javax.swing.JButton();
        J_btn = new javax.swing.JButton();
        K_btn = new javax.swing.JButton();
        L_btn = new javax.swing.JButton();
        Z_btn = new javax.swing.JButton();
        X_btn = new javax.swing.JButton();
        V_btn = new javax.swing.JButton();
        C_btn = new javax.swing.JButton();
        B_btn = new javax.swing.JButton();
        N_btn = new javax.swing.JButton();
        M_btn = new javax.swing.JButton();
        Menu_btn = new javax.swing.JButton();
        New_btn = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        Hangman_label = new javax.swing.JLabel();
        Timer_lable = new javax.swing.JLabel();
        Score_lable = new javax.swing.JLabel();
        Help_btn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Main_panel.setBackground(new java.awt.Color(0, 102, 0));

        QWERTY_keyboard.setBackground(new java.awt.Color(0, 102, 0));

        Q_btn.setText("Q");
        Q_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        W_btn.setText("W");
        W_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        R_btn.setText("R");
        R_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        E_btn.setText("E");
        E_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        T_btn.setText("T");
        T_btn.setMaximumSize(new java.awt.Dimension(25, 23));
        T_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T_btnActionPerformed(evt);
            }
        });

        Y_btn.setText("Y");
        Y_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        U_btn.setText("U");
        U_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        I_btn.setText("I");
        I_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        O_btn.setText("O");
        O_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        P_btn.setText("P");
        P_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        A_btn.setText("A");
        A_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        S_btn.setText("S");
        S_btn.setMaximumSize(new java.awt.Dimension(25, 23));
        S_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                S_btnActionPerformed(evt);
            }
        });

        D_btn.setText("D");
        D_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        F_btn.setText("F");
        F_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        G_btn.setText("G");
        G_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        H_btn.setText("H");
        H_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        J_btn.setText("J");
        J_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        K_btn.setText("K");
        K_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        L_btn.setText("L");
        L_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        Z_btn.setText("Z");
        Z_btn.setMaximumSize(new java.awt.Dimension(25, 23));
        Z_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Z_btnActionPerformed(evt);
            }
        });

        X_btn.setText("X");
        X_btn.setMaximumSize(new java.awt.Dimension(25, 23));
        X_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                X_btnActionPerformed(evt);
            }
        });

        V_btn.setText("V");
        V_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        C_btn.setText("C");
        C_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        B_btn.setText("B");
        B_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        N_btn.setText("N");
        N_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        M_btn.setText("M");
        M_btn.setMaximumSize(new java.awt.Dimension(25, 23));

        javax.swing.GroupLayout QWERTY_keyboardLayout = new javax.swing.GroupLayout(QWERTY_keyboard);
        QWERTY_keyboard.setLayout(QWERTY_keyboardLayout);
        QWERTY_keyboardLayout.setHorizontalGroup(
            QWERTY_keyboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(QWERTY_keyboardLayout.createSequentialGroup()
                .addGroup(QWERTY_keyboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(QWERTY_keyboardLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(Q_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(W_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(E_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(R_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(T_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Y_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(U_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(I_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(O_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(P_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(QWERTY_keyboardLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(A_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(QWERTY_keyboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(QWERTY_keyboardLayout.createSequentialGroup()
                                .addComponent(Z_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(X_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(C_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(V_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(B_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(N_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(M_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(QWERTY_keyboardLayout.createSequentialGroup()
                                .addComponent(S_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(D_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(F_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(G_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(H_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(J_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(K_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(L_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        QWERTY_keyboardLayout.setVerticalGroup(
            QWERTY_keyboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(QWERTY_keyboardLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(QWERTY_keyboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Q_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(W_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(R_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(E_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(T_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Y_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(U_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(I_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(O_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(P_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(QWERTY_keyboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(S_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(F_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(D_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(G_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(H_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(J_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(K_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(L_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(A_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(QWERTY_keyboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Z_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(X_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(V_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(C_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(B_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(N_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(M_btn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        Menu_btn.setText("Menu");
        Menu_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Menu_btnActionPerformed(evt);
            }
        });

        New_btn.setText("New");
        New_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                New_btnActionPerformed(evt);
            }
        });

        jTextField1.setEditable(false);
        jTextField1.setBackground(new java.awt.Color(51, 255, 255));
        jTextField1.setFont(new java.awt.Font("Humanst521 BT", 3, 24)); // NOI18N
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        Help_btn.setText("Help");
        Help_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Help_btnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Main_panelLayout = new javax.swing.GroupLayout(Main_panel);
        Main_panel.setLayout(Main_panelLayout);
        Main_panelLayout.setHorizontalGroup(
            Main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Main_panelLayout.createSequentialGroup()
                .addGroup(Main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Main_panelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jTextField1))
                    .addGroup(Main_panelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(New_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Menu_btn, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Help_btn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                        .addComponent(Score_lable, javax.swing.GroupLayout.PREFERRED_SIZE, 207, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Timer_lable, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)))
                .addContainerGap())
            .addComponent(Hangman_label, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Main_panelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(QWERTY_keyboard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
        );
        Main_panelLayout.setVerticalGroup(
            Main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Main_panelLayout.createSequentialGroup()
                .addGroup(Main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Main_panelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(Main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(Menu_btn)
                            .addComponent(Help_btn))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(New_btn))
                    .addGroup(Main_panelLayout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(Main_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Score_lable, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Timer_lable, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Hangman_label, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(QWERTY_keyboard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Main_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Main_panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void T_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T_btnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T_btnActionPerformed

    private void Z_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Z_btnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Z_btnActionPerformed

    private void S_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_S_btnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_S_btnActionPerformed

    private void X_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_X_btnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_X_btnActionPerformed

    private void New_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_New_btnActionPerformed
        // TODO add your handling code here:
        // Starts the game
        initializeGame();
        // Enables the keybooard
        Keyboard_enable(true);
        
        
        // Stops timer 
        stopTimer();
    }//GEN-LAST:event_New_btnActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void Menu_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Menu_btnActionPerformed
        // TODO add your handling code here:
        
        // Open the new JFrame
        Main_form menu_open = new Main_form();
        menu_open.setVisible(true);
        // Closes this form
        this.dispose();
        
        // Stops timer 
        stopTimer();
    }//GEN-LAST:event_Menu_btnActionPerformed

    private void Help_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Help_btnActionPerformed
        // TODO add your handling code here:
        
         // Open the new JFrame
        Help_mainframe help = new Help_mainframe ();
        help.setVisible(true);

        // Close the main frame
        this.dispose();
        
        // Stops timer 
        stopTimer();
    }//GEN-LAST:event_Help_btnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Game_frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Game_frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Game_frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Game_frame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Game_frame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton A_btn;
    private javax.swing.JButton B_btn;
    private javax.swing.JButton C_btn;
    private javax.swing.JButton D_btn;
    private javax.swing.JButton E_btn;
    private javax.swing.JButton F_btn;
    private javax.swing.JButton G_btn;
    private javax.swing.JButton H_btn;
    private javax.swing.JLabel Hangman_label;
    private javax.swing.JButton Help_btn;
    private javax.swing.JButton I_btn;
    private javax.swing.JButton J_btn;
    private javax.swing.JButton K_btn;
    private javax.swing.JButton L_btn;
    private javax.swing.JButton M_btn;
    private javax.swing.JPanel Main_panel;
    private javax.swing.JButton Menu_btn;
    private javax.swing.JButton N_btn;
    private javax.swing.JButton New_btn;
    private javax.swing.JButton O_btn;
    private javax.swing.JButton P_btn;
    private javax.swing.JPanel QWERTY_keyboard;
    private javax.swing.JButton Q_btn;
    private javax.swing.JButton R_btn;
    private javax.swing.JButton S_btn;
    private javax.swing.JLabel Score_lable;
    private javax.swing.JButton T_btn;
    private javax.swing.JLabel Timer_lable;
    private javax.swing.JButton U_btn;
    private javax.swing.JButton V_btn;
    private javax.swing.JButton W_btn;
    private javax.swing.JButton X_btn;
    private javax.swing.JButton Y_btn;
    private javax.swing.JButton Z_btn;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
